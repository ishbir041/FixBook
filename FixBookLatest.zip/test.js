// function sleep(ms) {
//   return new Promise(resolve => setTimeout(resolve, ms));
// }

// async function demo() {
//     var i=1;
//     while(1){
//         var d = new Date();
//         await sleep(5000);
//         if 
//         console.log(Math.floor(d.getTime()/60000));
//     }
// }

// var isFirst = localStorage.getItem("firstRun");

// if (isFirst==null || isFirst==1){
//     console.log("First Run");
//     demo();
//     localStorage.setItem("firstRun",0);
// }else{
//     console.log("consequent");
// }

console.log("poop");